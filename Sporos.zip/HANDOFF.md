# Sporos — redesign handoff for Claude Code

Paste the block below into Claude Code (run it from the root of the
`adamlewis83-hash/tournament-builder` repo). It points Claude at the design
mockups and tells it exactly what to implement.

---

## Paste this into Claude Code

I have redesign mockups for the Sporos app (this repo). They live in a separate
design file (`Sporos Screens.dc.html`) — I'll paste the relevant screen's HTML
when you ask, or you can work from the descriptions below. Please implement them
in the real Next.js app, reusing existing components, tokens, and Tailwind
classes. Do NOT introduce new colors, fonts, or a design system — everything
must use the existing CSS variables in `src/app/globals.css` (`--brand`,
`--surface`, `--muted`, `--border`, `--win`, etc.), the `Space Grotesk` /
`Geist` fonts already wired up, and the Phosphor duotone icons re-exported from
`src/components/icons.tsx` and `src/components/SportIcon.tsx`.

Scope — five screens, each a refinement of what exists today (nothing removed,
same data, same routes):

1. **Home tournament cards** (`src/components/TournamentList.tsx`)
   - Add a left sport-tinted accent rail per card.
   - Replace the buried "6/12 games played" text with a real progress bar
     (games played ÷ total).
   - Add a status pill top-right: LIVE (pulsing, only when `liveCode` is set),
     Final (when `getResult(t).complete`), or Setup (when `!t.generated`).
   - One clear primary action (Open / View results / Finish setup). Move
     Duplicate/Delete into an overflow (⋯) menu instead of always-visible.
   - Keep the rotating `SportBackdrop` banner on Home EXACTLY as-is — do not
     touch it.

2. **Live scoring** (`src/components/MatchCard.tsx`, `ScheduleView.tsx`,
   `src/app/t/[id]/page.tsx`)
   - Promote the currently-playing match to a "Now on Court" hero card: large
     +/- steppers and a big tappable score (replace the tiny 48px number
     inputs), clear "Leading" emphasis on the winning side, prominent court +
     timer chip.
   - Remaining matches stay as a compact "Up next" list below.

3. **New tournament** (`src/components/CreateTournamentForm.tsx`)
   - Turn the long vertical format list into a 2-column tile grid (icon +
     label); show the selected format's blurb in a single info strip, not a
     blurb under every option.
   - Numbered steps (Name & sport → Format → Play style) + a sticky
     Create action bar at the bottom.

4. **Golf** (`src/components/GolfView.tsx`)
   - Hole-progress dots row; larger per-player +/- steppers; a compact live
     to-par leaderboard above the full scorecard (scorecard stays, collapsible).

5. **Records** (`src/app/records/page.tsx`) & **Standings**
   (`src/components/StandingsTable.tsx`)
   - Records: add a gold/silver/bronze podium above the Hall of Fame table.
   - Standings: add a dashed "Top N advance" cutline between the advancing rows
     and the rest (N = `config.advanceCount`).

6. **Sport icons** (`src/components/SportIcon.tsx`)
   - Replace the generic Phosphor sport glyphs (several are weak or shared —
     e.g. `ph-target` standing in for cornhole, pickleball ≈ table tennis) with
     a custom monoline set: one 24px grid, 1.7px stroke, equipment
     silhouettes. Covered: Pickleball (wiffle ball), Golf (club + ball on
     ground), Tennis (racquet + ball), Table Tennis (solid bat + ball),
     Foosball (rod figure), Basketball, Cornhole (angled board + bag),
     Spikeball (net ring + ball), Volleyball, Soccer, Custom.
   - The SVGs are plain inline `<svg>` using `currentColor`, so they inherit the
     sport tint already applied to the icon chip — copy each `<svg>…</svg>` from
     the `4a` section of `Sporos Screens.dc.html` (I'll paste them when you get
     here) and map one per sport key.

Both light and dark themes must work (tokens already handle this — just use the
variables). Start with #1 and #2 (highest traffic). Show me a diff per screen
before moving on.

---

## Notes for reference
- Mockups are organized in `Sporos Screens.dc.html` as: turn 1 = faithful
  recreation of current screens (1a–1j), turn 2 = Home (2a) + Live (2b)
  redesigns, turn 3 = New tournament (3a), Golf (3b), Records (3c),
  Standings (3d), Settings (3e), turn 4 = custom sport icons (4a specimen,
  4b in-context on cards).
- The mockups are static HTML for visual reference only — the real logic
  (Zustand store, bracket/standings/golf libs) is untouched and stays the
  source of truth.
